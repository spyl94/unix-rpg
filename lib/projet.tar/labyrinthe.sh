#!/bin/bash
echo A Maze Ing by Damos l@bs

function newchar {
count=0
read -p 'Quel est ton nom? ' nom
read -p 'D�cris toi ' description
pvmax=$((10 + ($RANDOM % 10)))
pv=$pvmax
echo Vous avez $pvmax PV.
echo Choississez votre arme dans la liste.
echo
cut -d: -f1,2 ./lib/armes.txt | head -n 3
echo
read -p 'Selectionnez le num�ro de votre arme' nbarme
echo "$nom" > char.txt
echo "$description" >> char.txt
echo "$pvmax" >> char.txt
echo "$pv" >> char.txt
sed -n $nbarme'p' ./lib/armes.txt >> char.txt
}

function perso {
nb=0
declare -a affichage
while read ligne
do
affichage[$nb]=$ligne 
nb=$nb+1
done < char.txt
echo -e "\nFiche de personnage :"
echo Nom : ${affichage[0]}
echo Description : ${affichage[1]}
echo PV Max : ${affichage[2]}
echo PV Courrant : ${affichage[3]}
echo Arme :  ${affichage[4]}
echo -e "Lieu : ${affichage[5]}\n"
}


function menu {
	echo Menu:
	echo "1) Nouvelle partie"
	echo "2) Charger une partie"
	echo "3) Sauvegarder la partie en cours"
	echo "4) Voir la feuille de personnage"
	echo "5) Quitter"
	read choice
	if (($choice == 1))
	then
	newchar 
	elif(($choice == 4))
	then
	perso 
	fi
}
menu

